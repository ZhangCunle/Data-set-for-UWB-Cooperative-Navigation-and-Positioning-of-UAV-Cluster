% Environment0-Flying_straight

clc
clear
close all

Envir_Flag = 0;
Flying_Flag = '00';
MSE_All = [];
% Accessing trajectory point1 to point9
for i = 1:9
    % Accessing the results of four measurement channels
    for j = 1:4
        % Read the original ranging data frame
        Data_hex = Get_range_frame(i, j);
        % Obtain the ranging matrix based on data frame parsing
        Distance = Code_recode(Data_hex);
        % Save ranging matrix
        [~,~] = Save_Distance_AL(Distance, i, j);
        % Obtain the reference base station position matrix in this scenario
        Anchor = Get_Anchor(Envir_Flag);
        % Calculate preliminary position based on distance measurement matrix
        Position = Code_position(Anchor,Distance);
        % Save the calculated position matrix
        [~,~] = Save_Position(Position, i, j);
        % Calculate the distance between UAV nodes
        Distance_label_label = Distance_L_L_comput(Position);
        % Save the distance matrix between UAV nodes
        [~,~] = Save_Distance_LL(Distance_label_label, i, j);
        % Obtain the pre-set trajectory position of the corresponding flight formation in the corresponding scene
        Position_true = Get_Position_true(Flying_Flag,i);
        % Positioning accuracy calculation
        Dis_Mse = Position_Error_process(Position,Position_true);
        % Accumulated positioning error
        MSE_All = cat(2, MSE_All, Dis_Mse');
    end
end

% Accessing trajectory point10 to point30
for i = 10:30
    % Accessing the results of four measurement channels
    for j = 1:4
        % Read the original ranging data frame
        Data_hex = Get_range_frame(i, j);
        % Obtain the ranging matrix based on data frame parsing
        Distance = Code_recode(Data_hex);
        % Save ranging matrix
        [~,~] = Save_Distance_AL(Distance, i, j);
        % Obtain the reference base station position matrix in this scenario
        Anchor = Get_Anchor(Envir_Flag);
        % Calculate preliminary position based on distance measurement matrix
        Position = Code_position(Anchor,Distance);
        % Save the calculated position matrix
        [~,~] = Save_Position(Position, i, j);
        % Calculate the distance between UAV nodes
        Distance_label_label = Distance_L_L_comput(Position);
        % Save the distance matrix between UAV nodes
        [~,~] = Save_Distance_LL(Distance_label_label, i, j);
        % Obtain the pre-set trajectory position of the corresponding flight formation in the corresponding scene
        Position_true = Get_Position_true(Flying_Flag,i);
        % Positioning accuracy calculation
        Dis_Mse = Position_Error_process(Position,Position_true);
        % Accumulated positioning error
        MSE_All = cat(2, MSE_All, Dis_Mse');
    end
end

H_Straight = histogram(MSE_All./100,200,'FaceColor',[1, 0.84314, 0],'EdgeColor',[1, 0.84314, 0]);
H_Straight.Normalization = 'probability';
title('Positioning Error [m]:Outdoor Straight');
xlabel('Positioning Error [m]');
ylabel('Probability');
legend('Flying Straight');
grid on
